<div class="wpil_styles" style="min-height: 200px">
    <h3 style="display: inline-block;"><?php _e('Suggestions not available.', 'wpil') ?></h3>
    <br />
    <p style="display: inline-block;"><?php _e('Please save the post, (draft, publish or schedule), and reload the page to generate suggestions.', 'wpil') ?></p>
</div>
